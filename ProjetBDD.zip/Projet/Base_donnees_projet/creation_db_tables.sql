CREATE DATABASE IF NOT EXISTS cooking;

USE cooking;

#CREATE USER 'cooking'@'localhost' IDENTIFIED BY 'mdpBDD';
#GRANT ALL PRIVILEGES ON cooking.* TO 'cooking'@'localhost';

CREATE TABLE IF NOT EXISTS client (
nom VARCHAR(50) PRIMARY KEY NOT NULL,
num_tel VARCHAR(50) CHECK(LENGTH(num_tel) = 10), 
solde_cook INT DEFAULT '0',
cdr BIT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS connexion (
nom_utilisateur VARCHAR(50) PRIMARY KEY NOT NULL,
mdp_utilisateur VARCHAR(50),
admin BIT DEFAULT 0,
FOREIGN KEY (nom_utilisateur) REFERENCES client(nom)
);

CREATE TABLE IF NOT EXISTS recette (
nom VARCHAR(30) PRIMARY KEY NOT NULL,
type VARCHAR(30) NOT NULL,
description TEXT,
prix_vente INT CHECK(prix_vente>=10 AND prix_vente<=40),
id_createur VARCHAR(50),
FOREIGN KEY (id_createur) REFERENCES client(nom)
);

CREATE TABLE IF NOT EXISTS commande (
num_commande INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
date DATETIME DEFAULT CURRENT_TIMESTAMP,
id_client VARCHAR(50),
nom_recette VARCHAR(30) NOT NULL,
FOREIGN KEY (id_client) REFERENCES client(nom),
FOREIGN KEY (nom_recette) REFERENCES recette(nom)
);

CREATE TABLE IF NOT EXISTS fournisseur (
ref INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
num_tel VARCHAR(50) 
);

CREATE TABLE IF NOT EXISTS produit (
nom VARCHAR(30) PRIMARY KEY NOT NULL,
categorie VARCHAR(30) NOT NULL,
stock_actuel INT,
stock_min INT,
stock_max INT,
nom_recette VARCHAR(30),
unite_quantite VARCHAR(10),
quantite FLOAT, 
ref_fournisseur INT NOT NULL,
FOREIGN KEY (nom_recette) REFERENCES recette(nom),
FOREIGN KEY (ref_fournisseur) REFERENCES fournisseur(ref)
);