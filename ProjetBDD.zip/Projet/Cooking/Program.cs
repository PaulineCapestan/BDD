﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.IO;

namespace Cooking
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=cooking;UID=cooking;PASSWORD=mdpBDD;";
            MySqlConnection connection = new MySqlConnection(connectionString);

            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT client.nom, recette.nom " +
                                  "FROM client, recette " +
                                  "WHERE recette.id_createur = client.id AND recette.nom = 'Tarte au citron';"; 

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string nom_personne = "";
            string nom_recette = "";

            while (reader.Read()) //Parcours ligne par ligne
            {
                nom_personne = reader.GetString(0); //récupération de la 1ère colonne 
                nom_recette = reader.GetString(1);
                Console.WriteLine($"{nom_personne} -- {nom_recette}");
            }

            Console.ReadKey();

            connection.Close();
        }
    }
}
