﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;

namespace WPF_Cooking
{
    /// <summary>
    /// Logique d'interaction pour ConnexionClient.xaml
    /// </summary>
    public partial class ConnexionClient : Window
    {
        public ConnexionClient()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=cooking;UID=cooking;PASSWORD=mdpBDD;";
            MySqlConnection connection = new MySqlConnection(connectionString);

            try
            {
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                String query = "SELECT COUNT(1) FROM cooking.connexion WHERE nom_utilisateur=@nom_utilisateur AND mdp_utilisateur=@mdp_utilisateur";
                MySqlCommand sqlCmd = new MySqlCommand(query, connection);
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Parameters.AddWithValue("@nom_utilisateur", txtUtilisateur.Text);
                sqlCmd.Parameters.AddWithValue("@mdp_utilisateur", txtMdp.Text);
                int count = Convert.ToInt32(sqlCmd.ExecuteScalar());
                if (count == 1) 
                {
                    ClientInfo client = new ClientInfo();
                    client.Name = txtUtilisateur.Text;
                    MainWindow dashboard = new MainWindow(client);
                    dashboard.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Nom d'utilisateur ou mot de passe incorrect.");
                }
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                connection.Close();
            }
        }
    }

    public class ClientInfo
    {
        private string nameValue;
        private int soldeValue;

        public string Name
        {
            get { return nameValue; }
            set { nameValue = value; }
        }

        public int Solde
        {
            get { return soldeValue; }
            set { soldeValue = value; }
        }
    }
    
}
