﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using MySql.Data.MySqlClient;

namespace WPF_Cooking
{
    /// <summary>
    /// Logique d'interaction pour ConnexionAdmin.xaml
    /// </summary>
    public partial class ConnexionAdmin : Window
    {
        public ConnexionAdmin()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=cooking;UID=cooking;PASSWORD=mdpBDD;";
            MySqlConnection connection = new MySqlConnection(connectionString);

            try
            {
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                String query = "SELECT COUNT(1) FROM cooking.connexion WHERE nom_utilisateur=@nom_utilisateur AND mdp_utilisateur=@mdp_utilisateur AND admin=1";
                MySqlCommand sqlCmd = new MySqlCommand(query, connection);
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Parameters.AddWithValue("@nom_utilisateur", txtAdmin.Text);
                sqlCmd.Parameters.AddWithValue("@mdp_utilisateur", txtAdminMdp.Text);
                int count = Convert.ToInt32(sqlCmd.ExecuteScalar());
                if (count == 1)
                {
                    ClientInfo client = new ClientInfo();
                    client.Name = txtAdmin.Text;
                    MainWindow dashboard = new MainWindow(client);
                    dashboard.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Nom d'utilisateur / mot de passe incorrect ou accès non autorisé.");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                connection.Close();
            }

        }
    }
}
