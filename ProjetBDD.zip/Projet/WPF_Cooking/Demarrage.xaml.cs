﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Cooking
{
    /// <summary>
    /// Logique d'interaction pour demarrage.xaml
    /// </summary>
    public partial class demarrage : Window
    {
        public demarrage()
        {
            InitializeComponent();
        }

        private void btnInscription_Click(object sender, RoutedEventArgs e)
        {
            Inscription inscript_client = new Inscription();
            inscript_client.Show();
            this.Close();
        }

        private void btnClient_Click(object sender, RoutedEventArgs e)
        {
            ConnexionClient connect_client = new ConnexionClient();
            connect_client.Show();
            this.Close();
        }

        private void btnAdmin_Click(object sender, RoutedEventArgs e)
        {
            ConnexionAdmin connect_admin = new ConnexionAdmin();
            connect_admin.Show();
            this.Close();
        }
    }
}
