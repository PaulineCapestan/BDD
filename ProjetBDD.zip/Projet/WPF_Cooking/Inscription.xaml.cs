﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;

namespace WPF_Cooking
{
    /// <summary>
    /// Logique d'interaction pour Inscription.xaml
    /// </summary>
    public partial class Inscription : Window
    {
        public Inscription()
        {
            InitializeComponent();
        }

        private void btnInscript_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=cooking;UID=cooking;PASSWORD=mdpBDD;";
            MySqlConnection connection = new MySqlConnection(connectionString);

            try
            {
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                
                String query_verif_nom = "SELECT COUNT(1) FROM cooking.connexion WHERE nom_utilisateur=@nom_utilisateur";
                MySqlCommand sqlCmd3 = new MySqlCommand(query_verif_nom, connection);
                sqlCmd3.CommandType = CommandType.Text;
                sqlCmd3.Parameters.AddWithValue("@nom_utilisateur", txtUtilisateur.Text);
                
                int count = Convert.ToInt32(sqlCmd3.ExecuteScalar());
                if (count == 0)
                {
                    String query_add_client = "INSERT INTO `cooking`.`client` (`nom`, `num_tel`) VALUES (@nom_utilisateur, @numtel)";
                    MySqlCommand sqlCmd2 = new MySqlCommand(query_add_client, connection);
                    sqlCmd2.CommandType = CommandType.Text;
                    sqlCmd2.Parameters.AddWithValue("@nom_utilisateur", txtUtilisateur.Text);
                    sqlCmd2.Parameters.AddWithValue("@numtel", txtNumtel.Text);
                    sqlCmd2.ExecuteNonQuery();

                    String query_add_connexion = "INSERT INTO `cooking`.`connexion` (`nom_utilisateur`, `mdp_utilisateur`) VALUES (@nom_utilisateur, @mdp_utilisateur)";
                    MySqlCommand sqlCmd1 = new MySqlCommand(query_add_connexion, connection);
                    sqlCmd1.CommandType = CommandType.Text;
                    sqlCmd1.Parameters.AddWithValue("@nom_utilisateur", txtUtilisateur.Text);
                    sqlCmd1.Parameters.AddWithValue("@mdp_utilisateur", txtMdp.Text);
                    sqlCmd1.ExecuteNonQuery();

                    ConnexionClient login = new ConnexionClient();
                    login.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Nom d'utilisateur déjà pris");
                }
            }

            catch (Exception ex)
            {
                if (ex.Message == "Check constraint 'client_chk_1' is violated.")
                    MessageBox.Show("Le numéro de téléphone n'est pas au bon format.");
                else
                    MessageBox.Show(ex.Message);
            }

            finally
            {
                connection.Close();
            }

        }
    }
}
