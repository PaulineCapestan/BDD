﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;

namespace WPF_Cooking
{
    /// <summary>
    /// Logique d'interaction pour Commande.xaml
    /// </summary>
    public partial class Commande : Window
    {
        public static ClientInfo tmp;

        public Commande(ClientInfo client)
        {
            InitializeComponent();

            tmp = client;

            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=cooking;UID=cooking;PASSWORD=mdpBDD;";
            MySqlConnection connection = new MySqlConnection(connectionString);

            if (connection.State == ConnectionState.Closed)
                connection.Open();

            String query = "SELECT * FROM recette";
            MySqlCommand sqlCmd = new MySqlCommand(query, connection);
            sqlCmd.CommandType = CommandType.Text;

            MySqlDataReader reader;
            reader = sqlCmd.ExecuteReader();

            Recettes rec = new Recettes();

            while (reader.Read()) //Parcours ligne par ligne
            {
                rec.nom = reader.GetString(0); //récupération de la 1ère colonne 
                rec.type = reader.GetString(1);
                rec.texte = reader.GetString(2);
                rec.prix_vente = Convert.ToInt32(reader.GetString(3));
            }

            DataContext = rec;
            connection.Close();
        }
   

        public class Recettes
        {
            public string nom { get; set; }
            public string type { get; set; }
            public string texte { get; set; }
            public int prix_vente { get; set; }
        }
    }
}
